// ==UserScript==
// @name         自动查询淘宝taobao，天猫tmall内部隐藏大额优惠券,支持天猫超市、天猫国际站,一键直达领取页面，简单又省钱
// @name:zh-TW   自動查詢淘寶taobao，天貓tmall內部隱藏大額優惠券,支持天貓超市、天貓國際站,壹鍵直達領取頁面，簡單又省錢
// @namespace    https://www.jrtjt.cn/
// @version      2.0.1
// @description  自动查询淘宝taobao，天猫tmall、天猫超市、天猫国际站内部隐藏内部大额优惠券,有优惠券商品直接显示优惠券金额，一键直达淘宝官方优惠券领取页面，不经过第三方导购页面，简化操作步骤，支持淘宝网，天猫，天猫超市，天猫国际，阿里健康大药房。
// @description:zh-tw  自自動查詢淘寶taobao，天貓tmall、天貓超市、天貓國際站內部隱藏內部大額優惠券,有優惠券商品直接顯示優惠券金額，壹鍵直達淘寶官方優惠券領取頁面，不經過第三方導購頁面，簡化操作步驟，支持淘寶網，天貓，天貓超市，天貓國際，阿裏健康大藥房。
// @author       shanelee
// @match        *://item.taobao.com/*
// @match        *://detail.tmall.com/*
// @match        *://detail.tmall.hk/*
// @match        *://chaoshi.detail.tmall.com/*
// @match        *://detail.liangxinyao.com/*
// @require      https://cdn.bootcss.com/jquery/1.8.3/jquery.min.js
// @run-at       document-end
// @grant        unsafeWindow
// ==/UserScript==

(function() {
    $(document).ready(function() {
		var host = window.location.host;
        var itemName = '';//$(document).attr('title');
        var itemId = '';
        var Url = 'https://tb.jrtjt.cn/api'
        var link = window.location;
		// alert(link);
		if (host == 'item.taobao.com') {
            itemId = $("link[rel=canonical]").attr("href");
            itemId = itemId.split("id=")[1];
            itemName = $('.tb-main-title').attr('data-title');
            $.getJSON(''+ encodeURI(Url) +'?id='+ encodeURI(itemId) +'&itmename='+ encodeURI(itemName) +'',function(data){
                if(data.reslut == '200'){
                    $('.tb-action').append('<a style="display: inline-block;padding: 6px 12px;margin-bottom: 0;font-size: 14px;font-weight: normal;height:26px;line-height:26px;text-align: center;white-space: nowrap;vertical-align: middle;-ms-touch-action: manipulation;touch-action: manipulation;cursor: pointer;-webkit-user-select: none;-moz-user-select: none;-ms-user-select: none;user-select: none;background-image: none;border: 1px solid transparent;border-radius:2px;color: #fff;background-color: #DF231C;#FF0036;margin-left:10px" href="'+ encodeURI(data.item_coupon_url) +'" " target="_blank">'+ encodeURI(data.coupon_yun) +'优惠券</a>');
                }else if(data.reslut == '0'){
                    $('.tb-action').append('<a style="display: inline-block;padding: 6px 12px;margin-bottom: 0;font-size: 14px;font-weight: normal;height:26px;line-height:26px;text-align: center;white-space: nowrap;vertical-align: middle;-ms-touch-action: manipulation;touch-action: manipulation;cursor: pointer;-webkit-user-select: none;-moz-user-select: none;-ms-user-select: none;user-select: none;background-image: none;border: 1px solid transparent;border-radius:2px;color: #fff;background-color: #DF231C;#FF0036;margin-left:10px" href="https://www.jrtjt.cn/api/tbq?type=0&itmename='+ encodeURI(itemName) +'&id='+ encodeURI(itemId) +'" " target="_blank">暂无可用优惠券</a>');
                }
            });
		}else if(host == 'detail.tmall.com'){
            itemId = $("link[rel=canonical]").attr("href");
            itemId = itemId.split("id=")[1];
            itemName = $('meta[name=keywords]').attr('content');
            $.getJSON(Url,{itmename:itemName,id:itemId},function(data){
                if(data.reslut == '200'){
                    $('.tb-sku').append('<div class="tb-action" style="margin-top:0"><a style="display: inline-block;padding: 6px 12px;margin-bottom: 0;font-size: 14px;font-weight: normal;height:26px;line-height:26px;width:156px;text-align: center;white-space: nowrap;vertical-align: middle;-ms-touch-action: manipulation;touch-action: manipulation;cursor: pointer;-webkit-user-select: none;-moz-user-select: none;-ms-user-select: none;user-select: none;background-image: none;border: 1px solid transparent;border-radius:2px;color: #fff;background-color: #DF231C;#FF0036;" href="'+ encodeURI(data.item_coupon_url) +'" " target="_blank">'+ encodeURI(data.coupon_yun) +'优惠券</a></div>');
                }else if(data.reslut == '0'){
                    $('.tb-sku').append( '<div class="tb-action" style="margin-top:0"><a style="display: inline-block;padding: 6px 12px;margin-bottom: 0;font-size: 14px;font-weight: normal;height:26px;line-height:26px;width:156px;text-align: center;white-space: nowrap;vertical-align: middle;-ms-touch-action: manipulation;touch-action: manipulation;cursor: pointer;-webkit-user-select: none;-moz-user-select: none;-ms-user-select: none;user-select: none;background-image: none;border: 1px solid transparent;border-radius:2px;color: #fff;background-color: #DF231C;#FF0036;" href="https://www.jrtjt.cn/api/tbq?type=0&itmename='+ encodeURI(itemName) +'&id='+ encodeURI(itemId) +'" " target="_blank">暂无可用优惠券</a></div>');
                }
            });
        }else if(host == 'chaoshi.detail.tmall.com'){
            itemId = $('a[id=J_AddFavorite]').attr('data-aldurl');
            itemId = itemId.split("itemId=")[1];
            itemName = $('input[name=title]').attr('value');
            console.log(itemId)
            console.log(itemName)
            $.getJSON(Url,{itmename:itemName,id:itemId},function(data){
                console.log(data)
                if(data.reslut == '200'){
                    $('.tb-sku').append('<div class="tb-action tb-btn-add tb-btn-sku"><a href="'+ encodeURI(data.item_coupon_url) +'" " target="_blank">'+ encodeURI(data.coupon_yun) +'优惠券</a></div>');
                }else if(data.reslut == '0'){
                    $('.tb-sku').append('<div class="tb-action tb-btn-add tb-btn-sku"><a href="https://www.jrtjt.cn/api/tbq?itmename='+ encodeURI(itemName) +'&id='+ encodeURI(itemId) +'" " target="_blank">暂无可用优惠券</a></div>');                }
            });
        }else if(host == 'detail.tmall.hk'){
            itemId = $("link[rel=canonical]").attr("href");
            itemId = itemId.split("id=")[1];
            itemName = $('meta[name=keywords]').attr('content');
            $.getJSON(Url,{itmename:itemName,id:itemId},function(data){
                if(data.reslut == '200'){
                    $('.tb-sku').append('<div class="tb-action" style="margin-top:0"><a style="display: inline-block;padding: 6px 12px;margin-bottom: 0;font-size: 14px;font-weight: normal;height:26px;line-height:26px;width:156px;text-align: center;white-space: nowrap;vertical-align: middle;-ms-touch-action: manipulation;touch-action: manipulation;cursor: pointer;-webkit-user-select: none;-moz-user-select: none;-ms-user-select: none;user-select: none;background-image: none;border: 1px solid transparent;border-radius:2px;color: #fff;background-color: #DF231C;#FF0036;" href="'+ encodeURI(data.item_coupon_url) +'" " target="_blank">'+ encodeURI(data.coupon_yun) +'优惠券</a></div>');
                }else if(data.reslut == '0'){
                    $('.tb-sku').append( '<div class="tb-action" style="margin-top:0"><a style="display: inline-block;padding: 6px 12px;margin-bottom: 0;font-size: 14px;font-weight: normal;height:26px;line-height:26px;width:156px;text-align: center;white-space: nowrap;vertical-align: middle;-ms-touch-action: manipulation;touch-action: manipulation;cursor: pointer;-webkit-user-select: none;-moz-user-select: none;-ms-user-select: none;user-select: none;background-image: none;border: 1px solid transparent;border-radius:2px;color: #fff;background-color: #DF231C;#FF0036;" href="https://www.jrtjt.cn/api/tbq?type=0&itmename='+ encodeURI(itemName) +'&id='+ encodeURI(itemId) +'" " target="_blank">暂无可用优惠券</a></div>');
                }
            });
        }else if(host == 'detail.liangxinyao.com'){
            itemId = $("link[rel=canonical]").attr("href");
            itemId = itemId.split("id=")[1];
            itemName = $('meta[name=keywords]').attr('content');
            $.getJSON(Url,{itmename:itemName,id:itemId},function(data){
                if(data.reslut == '200'){
                    $('.tb-sku').append('<div class="tb-action" style="margin-top:0"><a style="display: inline-block;padding: 6px 12px;margin-bottom: 0;font-size: 14px;font-weight: normal;height:26px;line-height:26px;width:156px;text-align: center;white-space: nowrap;vertical-align: middle;-ms-touch-action: manipulation;touch-action: manipulation;cursor: pointer;-webkit-user-select: none;-moz-user-select: none;-ms-user-select: none;user-select: none;background-image: none;border: 1px solid transparent;border-radius:2px;color: #fff;background-color: #DF231C;#FF0036;" href="'+ encodeURI(data.item_coupon_url) +'" " target="_blank">'+ encodeURI(data.coupon_yun) +'优惠券</a></div>');
                }else if(data.reslut == '0'){
                    $('.tb-sku').append( '<div class="tb-action" style="margin-top:0"><a style="display: inline-block;padding: 6px 12px;margin-bottom: 0;font-size: 14px;font-weight: normal;height:26px;line-height:26px;width:156px;text-align: center;white-space: nowrap;vertical-align: middle;-ms-touch-action: manipulation;touch-action: manipulation;cursor: pointer;-webkit-user-select: none;-moz-user-select: none;-ms-user-select: none;user-select: none;background-image: none;border: 1px solid transparent;border-radius:2px;color: #fff;background-color: #DF231C;#FF0036;" href="https://www.jrtjt.cn/api/tbq?type=0&itmename='+ encodeURI(itemName) +'&id='+ encodeURI(itemId) +'" " target="_blank">暂无可用优惠券</a></div>');
                }
            });
        }
    });
})();